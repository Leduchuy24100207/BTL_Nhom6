"""Các lớp dữ liệu của hệ thống."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

from .errors import ValidationError


class Role(str, Enum):
    CUSTOMER = "customer"
    DRIVER = "driver"
    ADMIN = "admin"


class ServiceType(str, Enum):
    BIKE = "bike"
    CAR4 = "car4"
    CAR7 = "car7"


class PaymentMethod(str, Enum):
    CASH = "cash"          # tiền mặt: tài xế thu, bị trừ chiết khấu từ ví
    CARD = "card"          # thanh toán qua app: ví tài xế được cộng
    E_WALLET = "e_wallet"  # thanh toán qua app: ví tài xế được cộng


class RideStatus(str, Enum):
    SEARCHING = "searching"        # đang tìm / đã gửi đề nghị cho tài xế
    NO_DRIVER = "no_driver"        # không tìm được tài xế
    ACCEPTED = "accepted"          # tài xế đã nhận, đang đến đón
    IN_PROGRESS = "in_progress"    # khách đã lên xe
    COMPLETED = "completed"
    CANCELLED = "cancelled"


ACTIVE_STATUSES = {RideStatus.SEARCHING, RideStatus.NO_DRIVER,
                   RideStatus.ACCEPTED, RideStatus.IN_PROGRESS}

STATUS_LABELS = {
    RideStatus.SEARCHING: "Đang tìm tài xế",
    RideStatus.NO_DRIVER: "Chưa tìm được tài xế",
    RideStatus.ACCEPTED: "Tài xế đang đến điểm đón",
    RideStatus.IN_PROGRESS: "Đang trong chuyến đi",
    RideStatus.COMPLETED: "Đã hoàn thành",
    RideStatus.CANCELLED: "Đã hủy",
}


@dataclass(frozen=True)
class Location:
    name: str
    lat: float
    lng: float

    def __post_init__(self):
        if not (-90 <= self.lat <= 90 and -180 <= self.lng <= 180):
            raise ValidationError("Toạ độ không hợp lệ")
        if not self.name or not self.name.strip():
            raise ValidationError("Tên địa điểm không được để trống")

    def to_dict(self) -> dict:
        return {"name": self.name, "lat": self.lat, "lng": self.lng}


@dataclass
class Rating:
    stars: int
    comment: str
    at: datetime


@dataclass
class User:
    username: str
    salt: str
    password_hash: str
    role: Role
    full_name: str = ""
    phone: str = ""
    email: str = ""
    locked: bool = False
    created_at: datetime | None = None
    rating_sum: int = 0
    rating_count: int = 0

    @property
    def avg_rating(self) -> float | None:
        return round(self.rating_sum / self.rating_count, 2) if self.rating_count else None


@dataclass
class DriverProfile:
    username: str
    service_type: ServiceType = ServiceType.CAR4
    plate: str = ""
    approved: bool = False         # admin cấp quyền hoạt động
    online: bool = False           # bật/tắt nhận chuyến
    wallet: int = 0
    location: Location | None = None
    current_ride_id: str | None = None
    accepted_count: int = 0
    rejected_count: int = 0
    completed_count: int = 0
    cancelled_count: int = 0       # tài xế tự hủy sau khi đã nhận


@dataclass
class Ride:
    id: str
    customer: str
    pickup: Location
    dropoff: Location
    service: ServiceType
    payment: PaymentMethod
    distance_km: float
    fare: int
    created_at: datetime
    booked_by: str
    status: RideStatus = RideStatus.SEARCHING
    driver: str | None = None
    offered_to: str | None = None
    declined_by: set[str] = field(default_factory=set)
    accepted_at: datetime | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None
    cancelled_by: str | None = None
    cancel_reason: str = ""
    commission_rate: float = 0.0
    commission: int = 0
    driver_net: int = 0
    driver_rating: Rating | None = None     # khách đánh giá tài xế
    customer_rating: Rating | None = None   # tài xế đánh giá khách

    def to_dict(self) -> dict:
        iso = lambda d: d.isoformat() if d else None
        return {
            "id": self.id, "customer": self.customer, "driver": self.driver,
            "status": self.status.value, "pickup": self.pickup.to_dict(),
            "dropoff": self.dropoff.to_dict(), "service": self.service.value,
            "payment": self.payment.value, "distance_km": self.distance_km,
            "fare": self.fare, "commission": self.commission, "driver_net": self.driver_net,
            "created_at": iso(self.created_at), "accepted_at": iso(self.accepted_at),
            "started_at": iso(self.started_at), "finished_at": iso(self.finished_at),
            "cancelled_by": self.cancelled_by, "cancel_reason": self.cancel_reason,
            "booked_by": self.booked_by,
            "driver_rating": self.driver_rating.stars if self.driver_rating else None,
            "customer_rating": self.customer_rating.stars if self.customer_rating else None,
        }


@dataclass
class Transaction:
    id: int
    driver: str
    kind: str            # topup | withdraw | commission | payout
    amount: int          # dương = cộng ví, âm = trừ ví
    balance_after: int
    at: datetime
    ride_id: str | None = None

    def to_dict(self) -> dict:
        return {"id": self.id, "driver": self.driver, "kind": self.kind,
                "amount": self.amount, "balance_after": self.balance_after,
                "at": self.at.isoformat(), "ride_id": self.ride_id}


@dataclass
class AuditEntry:
    at: datetime
    actor: str
    action: str
    ride_id: str | None
    detail: str

    def to_dict(self) -> dict:
        return {"at": self.at.isoformat(), "actor": self.actor, "action": self.action,
                "ride_id": self.ride_id, "detail": self.detail}
