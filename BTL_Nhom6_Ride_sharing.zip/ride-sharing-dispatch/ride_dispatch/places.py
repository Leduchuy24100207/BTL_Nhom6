"""Một số địa điểm mẫu (Hà Nội) để demo / dùng trong CLI."""
from .models import Location

PLACES: dict[str, Location] = {
    "Hồ Gươm": Location("Hồ Gươm", 21.0285, 105.8523),
    "Văn Miếu": Location("Văn Miếu", 21.0293, 105.8355),
    "Bến xe Mỹ Đình": Location("Bến xe Mỹ Đình", 21.0286, 105.7783),
    "Royal City": Location("Royal City", 21.0033, 105.8147),
    "Time City": Location("Time City", 20.9952, 105.8683),
    "Aeon Long Biên": Location("Aeon Long Biên", 21.0267, 105.8995),
    "ĐH Phenikaa": Location("ĐH Phenikaa", 20.9625, 105.7467),
    "Sân bay Nội Bài": Location("Sân bay Nội Bài", 21.2187, 105.8042),
}
