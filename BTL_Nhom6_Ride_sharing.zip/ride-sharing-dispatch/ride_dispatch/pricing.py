"""Bảng giá cước theo loại dịch vụ."""
from dataclasses import dataclass

from .models import ServiceType


@dataclass
class Tariff:
    base_fare: int   # mở cửa (VND)
    per_km: int      # giá / km (VND)
    min_fare: int    # cước tối thiểu (VND)

    def fare(self, distance_km: float) -> int:
        raw = max(self.base_fare + self.per_km * distance_km, self.min_fare)
        return int(round(raw / 1000.0)) * 1000   # làm tròn 1.000đ


def default_tariffs() -> dict[ServiceType, Tariff]:
    return {
        ServiceType.BIKE: Tariff(base_fare=5_000, per_km=5_000, min_fare=12_000),
        ServiceType.CAR4: Tariff(base_fare=10_000, per_km=9_000, min_fare=25_000),
        ServiceType.CAR7: Tariff(base_fare=12_000, per_km=11_000, min_fare=30_000),
    }
