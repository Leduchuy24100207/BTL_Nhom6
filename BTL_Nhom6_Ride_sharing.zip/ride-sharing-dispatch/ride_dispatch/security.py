"""Băm mật khẩu (PBKDF2-SHA256) và sinh token phiên."""
import hashlib
import hmac
import secrets

ITERATIONS = 100_000


def hash_password(password: str, salt_hex: str | None = None) -> tuple[str, str]:
    salt = bytes.fromhex(salt_hex) if salt_hex else secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, ITERATIONS)
    return salt.hex(), digest.hex()


def verify_password(password: str, salt_hex: str, hash_hex: str) -> bool:
    _, digest = hash_password(password, salt_hex)
    return hmac.compare_digest(digest, hash_hex)


def new_token() -> str:
    return secrets.token_urlsafe(24)
