"""Lõi nghiệp vụ Ride-Sharing Dispatch System (in-memory).

Mọi hàm public nhận `token` (trả về từ `login`) làm tham số đầu tiên, trừ
`register` và `login`. Kết quả trả về là dict/list thuần để dễ test và dễ
gắn vào lớp API/giao diện sau này.
"""
from __future__ import annotations

import re
import threading
from datetime import date, datetime
from functools import wraps

from . import security
from .errors import (AuthError, DispatchError, NotFound, PermissionDenied, StateError,
                     ValidationError)
from .geo import haversine_km
from .models import (ACTIVE_STATUSES, STATUS_LABELS, AuditEntry, DriverProfile,
                     Location, PaymentMethod, Rating, Ride, RideStatus, Role,
                     ServiceType, Transaction, User)
from .pricing import Tariff, default_tariffs

USERNAME_RE = re.compile(r"^[a-z0-9_.]{3,30}$")
PHONE_RE = re.compile(r"^(0|\+84)\d{9}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


def _synchronized(cls):
    """Bọc mọi method public bằng RLock để an toàn khi dùng đa luồng."""
    def wrap(fn):
        @wraps(fn)
        def inner(self, *a, **k):
            with self._lock:
                try:
                    return fn(self, *a, **k)
                except DispatchError as exc:
                    self._notify_operation_error(fn.__name__, a, k, exc)
                    raise
        return inner
    for name, fn in list(vars(cls).items()):
        if callable(fn) and not name.startswith("_"):
            setattr(cls, name, wrap(fn))
    return cls


@_synchronized
class DispatchSystem:
    def __init__(self, clock=None, commission_rate: float = 0.20,
                 admin_code: str = "ADMIN2026", max_pickup_km: float = 10.0,
                 min_wallet_balance: int = 0):
        self._clock = clock or datetime.now
        self._commission_rate = commission_rate
        self._admin_code = admin_code
        self._max_pickup_km = max_pickup_km
        self._min_wallet = min_wallet_balance
        self._users: dict[str, User] = {}
        self._drivers: dict[str, DriverProfile] = {}
        self._rides: dict[str, Ride] = {}
        self._sessions: dict[str, str] = {}
        self._tariffs: dict[ServiceType, Tariff] = default_tariffs()
        self._ledger: list[Transaction] = []
        self._audit: list[AuditEntry] = []
        self._notifications: list[dict] = []
        self._notification_seq = 0
        self._ride_seq = 0
        self._lock = threading.RLock()

    # ------------------------------------------------------------------ helpers
    def _now(self) -> datetime:
        return self._clock()

    def _log(self, actor: str, action: str, detail: str = "", ride: Ride | None = None):
        self._audit.append(AuditEntry(self._now(), actor, action,
                                      ride.id if ride else None, detail))

    def _notify(self, recipient: str, message: str, source: str, error: str):
        self._notification_seq += 1
        self._notifications.append({
            "id": self._notification_seq, "recipient": recipient,
            "message": message, "source": source, "error": error,
            "at": self._now().isoformat(), "read": False,
        })

    def _notify_operation_error(self, operation: str, args: tuple, kwargs: dict, exc: DispatchError):
        """Gửi cảnh báo lỗi cho đúng người; không để lỗi thông báo che lỗi gốc."""
        try:
            token = args[0] if args else kwargs.get("token")
            username = self._sessions.get(token) if isinstance(token, str) else None
            # Đăng ký thất bại: có thể xác định người bị lỗi từ username/role.
            if operation == "register" and len(args) >= 3:
                username = str(args[0])
                role = str(getattr(args[2], "value", args[2])).lower()
            else:
                user = self._users.get(username) if username else None
                role = user.role.value if user else "unknown"
            if not username:
                return
            error = str(exc)
            message = f"Lỗi khi thực hiện '{operation}': {error}"
            recipients = {username}
            if role != "admin":
                recipients.update(u.username for u in self._users.values() if u.role is Role.ADMIN)
            for recipient in recipients:
                self._notify(recipient, message, operation, error)
            self._log(username, "operation_error", f"{operation}: {error}")
        except Exception:
            # Cơ chế cảnh báo không được làm thay đổi hành vi của lỗi ban đầu.
            pass

    @staticmethod
    def _enum(cls, value, label: str):
        if isinstance(value, cls):
            return value
        try:
            return cls(str(value).strip().lower())
        except ValueError:
            raise ValidationError(f"{label} không hợp lệ: {value!r}") from None

    @staticmethod
    def _check_contact(phone, email):
        if phone and not PHONE_RE.match(phone):
            raise ValidationError("Số điện thoại không hợp lệ (vd 0912345678 hoặc +84912345678)")
        if email and not EMAIL_RE.match(email):
            raise ValidationError("Email không hợp lệ")

    @staticmethod
    def _check_password(pw: str):
        if not isinstance(pw, str) or len(pw) < 6:
            raise ValidationError("Mật khẩu phải có ít nhất 6 ký tự")

    @staticmethod
    def _money(amount) -> int:
        if not isinstance(amount, int) or isinstance(amount, bool) or amount <= 0:
            raise ValidationError("Số tiền phải là số nguyên dương")
        return amount

    def _auth(self, token: str, *roles: Role) -> User:
        username = self._sessions.get(token)
        if username is None:
            raise AuthError("Chưa đăng nhập hoặc phiên đã hết hạn")
        user = self._users[username]
        if user.locked:
            self._sessions.pop(token, None)
            raise PermissionDenied("Tài khoản đã bị khóa")
        if roles and user.role not in roles:
            raise PermissionDenied("Bạn không có quyền thực hiện chức năng này")
        return user

    def _customer(self, token):  # khách hoặc admin
        return self._auth(token, Role.CUSTOMER, Role.ADMIN)

    def _driver(self, token) -> tuple[User, DriverProfile]:  # tài xế hoặc admin
        user = self._auth(token, Role.DRIVER, Role.ADMIN)
        return user, self._drivers[user.username]

    def _admin(self, token) -> User:
        return self._auth(token, Role.ADMIN)

    def _ride(self, ride_id: str) -> Ride:
        try:
            return self._rides[ride_id]
        except KeyError:
            raise NotFound(f"Không tìm thấy chuyến {ride_id}") from None

    def _user(self, username: str) -> User:
        try:
            return self._users[username.strip().lower()]
        except KeyError:
            raise NotFound(f"Không tìm thấy tài khoản {username}") from None

    def _can_work(self, dp: DriverProfile) -> bool:
        return (dp.approved and dp.online and dp.current_ride_id is None
                and dp.wallet >= self._min_wallet
                and not self._users[dp.username].locked)

    def _has_pending_offer(self, username: str) -> bool:
        return any(r.offered_to == username and r.status is RideStatus.SEARCHING
                   for r in self._rides.values())

    def _user_view(self, u: User) -> dict:
        d = {"username": u.username, "role": u.role.value, "full_name": u.full_name,
             "phone": u.phone, "email": u.email, "locked": u.locked,
             "rating": u.avg_rating, "rating_count": u.rating_count}
        if u.role in (Role.DRIVER, Role.ADMIN):
            dp = self._drivers[u.username]
            d.update(service_type=dp.service_type.value, plate=dp.plate,
                     approved=dp.approved, online=dp.online, wallet=dp.wallet)
        return d

    def _ride_view(self, r: Ride) -> dict:
        d = r.to_dict()
        d["status_label"] = STATUS_LABELS[r.status]
        if r.driver:
            du, dp = self._users[r.driver], self._drivers[r.driver]
            d["driver_info"] = {"name": du.full_name or du.username, "plate": dp.plate,
                                "service": dp.service_type.value, "rating": du.avg_rating}
        return d

    @staticmethod
    def _in_range(dt: datetime | None, d_from: date | None, d_to: date | None) -> bool:
        if dt is None:
            return False
        day = dt.date()
        return (d_from is None or day >= d_from) and (d_to is None or day <= d_to)

    # ------------------------------------------------------------ đăng ký / đăng nhập
    def register(self, username: str, password: str, role, full_name: str = "",
                 phone: str = "", email: str = "", service_type=None,
                 plate: str = "", admin_code: str | None = None) -> dict:
        uname = (username or "").strip().lower()
        if not USERNAME_RE.match(uname):
            raise ValidationError("Tên đăng nhập 3-30 ký tự: chữ thường, số, '_' hoặc '.'")
        if uname in self._users:
            raise ValidationError("Tên đăng nhập đã tồn tại")
        self._check_password(password)
        role = self._enum(Role, role, "Chức vụ")
        if role is Role.ADMIN and admin_code != self._admin_code:
            raise PermissionDenied("Mã xác thực admin không đúng")
        self._check_contact(phone, email)
        salt, digest = security.hash_password(password)
        user = User(uname, salt, digest, role, full_name.strip(), phone, email,
                    created_at=self._now())
        self._users[uname] = user
        if role is Role.DRIVER:
            st = self._enum(ServiceType, service_type or "car4", "Loại dịch vụ")
            self._drivers[uname] = DriverProfile(uname, st, plate.strip(), approved=False)
        elif role is Role.ADMIN:  # admin có đủ chức năng tài xế, tự động được cấp quyền
            self._drivers[uname] = DriverProfile(uname, ServiceType.CAR4, "ADMIN", approved=True)
        self._log(uname, "register", f"role={role.value}")
        return self._user_view(user)

    def login(self, username: str, password: str) -> dict:
        user = self._users.get((username or "").strip().lower())
        if user is None or not security.verify_password(password or "", user.salt, user.password_hash):
            raise AuthError("Sai tên đăng nhập hoặc mật khẩu")
        if user.locked:
            raise PermissionDenied("Tài khoản đã bị khóa")
        token = security.new_token()
        self._sessions[token] = user.username
        self._log(user.username, "login")
        return {"token": token, "user": self._user_view(user)}

    def logout(self, token: str) -> None:
        username = self._sessions.pop(token, None)
        if username:
            self._log(username, "logout")

    # ------------------------------------------------------------ thông tin cá nhân
    def get_profile(self, token: str) -> dict:
        return self._user_view(self._auth(token))

    def update_profile(self, token: str, full_name: str | None = None,
                       phone: str | None = None, email: str | None = None,
                       service_type=None, plate: str | None = None) -> dict:
        user = self._auth(token)
        self._check_contact(phone, email)
        if full_name is not None:
            if not full_name.strip():
                raise ValidationError("Họ và tên không được để trống")
            user.full_name = full_name.strip()
        if phone is not None:
            user.phone = phone
        if email is not None:
            user.email = email
        if service_type is not None or plate is not None:
            if user.role not in (Role.DRIVER, Role.ADMIN):
                raise PermissionDenied("Chỉ tài xế mới có thông tin phương tiện")
            dp = self._drivers[user.username]
            if service_type is not None:
                if dp.online or dp.current_ride_id:
                    raise StateError("Hãy tắt hoạt động và hoàn tất chuyến trước khi đổi loại xe")
                dp.service_type = self._enum(ServiceType, service_type, "Loại dịch vụ")
            if plate is not None:
                dp.plate = plate.strip()
        self._log(user.username, "update_profile")
        return self._user_view(user)

    def change_password(self, token: str, old_password: str, new_password: str,
                        confirm_password: str) -> None:
        user = self._auth(token)
        if not security.verify_password(old_password or "", user.salt, user.password_hash):
            raise AuthError("Mật khẩu cũ không đúng")
        self._check_password(new_password)
        if new_password != confirm_password:
            raise ValidationError("Mật khẩu nhập lại không khớp")
        if new_password == old_password:
            raise ValidationError("Mật khẩu mới phải khác mật khẩu cũ")
        user.salt, user.password_hash = security.hash_password(new_password)
        for t in [t for t, u in self._sessions.items() if u == user.username and t != token]:
            del self._sessions[t]  # đăng xuất các phiên khác
        self._log(user.username, "change_password")

    # ------------------------------------------------------------ khách hàng
    def quote_fare(self, token: str, pickup: Location, dropoff: Location,
                   service=None) -> list[dict]:
        self._customer(token)
        km = self._distance(pickup, dropoff)
        services = [self._enum(ServiceType, service, "Loại dịch vụ")] if service else list(ServiceType)
        return [{"service": s.value, "distance_km": km, "fare": self._tariffs[s].fare(km),
                 "per_km": self._tariffs[s].per_km} for s in services]

    @staticmethod
    def _distance(pickup: Location, dropoff: Location) -> float:
        km = round(haversine_km(pickup, dropoff), 2)
        if km < 0.1:
            raise ValidationError("Điểm đón và điểm đến quá gần nhau")
        return km

    def book_ride(self, token: str, pickup: Location, dropoff: Location, service,
                  payment, customer_username: str | None = None) -> dict:
        """Xác nhận đặt chuyến và bắt đầu tìm tài xế.
        Admin có thể đặt hộ khách bằng `customer_username`."""
        user = self._customer(token)
        if customer_username and customer_username.strip().lower() != user.username:
            if user.role is not Role.ADMIN:
                raise PermissionDenied("Chỉ admin mới đặt chuyến hộ khách")
            customer = self._user(customer_username)
            if customer.role is not Role.CUSTOMER:
                raise ValidationError("Tài khoản được đặt hộ phải là khách hàng")
        else:
            customer = user
        if customer.locked:
            raise PermissionDenied("Tài khoản khách hàng đang bị khóa")
        if any(r.customer == customer.username and r.status in ACTIVE_STATUSES
               for r in self._rides.values()):
            raise StateError("Khách hàng đang có một chuyến chưa kết thúc")
        service = self._enum(ServiceType, service, "Loại dịch vụ")
        payment = self._enum(PaymentMethod, payment, "Phương thức thanh toán")
        km = self._distance(pickup, dropoff)
        self._ride_seq += 1
        ride = Ride(id=f"R{self._ride_seq:04d}", customer=customer.username,
                    pickup=pickup, dropoff=dropoff, service=service, payment=payment,
                    distance_km=km, fare=self._tariffs[service].fare(km),
                    created_at=self._now(), booked_by=user.username)
        self._rides[ride.id] = ride
        self._log(user.username, "book", f"{pickup.name} -> {dropoff.name}, {ride.fare}đ", ride)
        self._dispatch(ride)
        return self._ride_view(ride)

    def retry_search(self, token: str, ride_id: str) -> dict:
        """Tìm lại tài xế khi chuyến đang ở trạng thái 'chưa tìm được tài xế'."""
        user = self._customer(token)
        ride = self._ride(ride_id)
        self._check_owner(user, ride)
        if ride.status is not RideStatus.NO_DRIVER:
            raise StateError("Chỉ tìm lại được khi chưa có tài xế")
        ride.declined_by.clear()
        self._log(user.username, "retry_search", ride=ride)
        self._dispatch(ride)
        return self._ride_view(ride)

    @staticmethod
    def _check_owner(user: User, ride: Ride):
        if user.role is not Role.ADMIN and ride.customer != user.username:
            raise PermissionDenied("Đây không phải chuyến của bạn")

    def get_ride(self, token: str, ride_id: str) -> dict:
        user = self._auth(token)
        ride = self._ride(ride_id)
        if user.role is not Role.ADMIN and user.username not in (ride.customer, ride.driver):
            raise PermissionDenied("Bạn không có quyền xem chuyến này")
        return self._ride_view(ride)

    def track_ride(self, token: str, ride_id: str) -> dict:
        """Trạng thái + vị trí tài xế (chỉ có vị trí khi đã có tài xế và chuyến chưa kết thúc)."""
        user = self._customer(token)
        ride = self._ride(ride_id)
        self._check_owner(user, ride)
        view = self._ride_view(ride)
        view["driver_location"] = None
        view["distance_to_target_km"] = None
        if ride.driver and ride.status in (RideStatus.ACCEPTED, RideStatus.IN_PROGRESS):
            loc = self._drivers[ride.driver].location
            if loc:
                view["driver_location"] = loc.to_dict()
                target = ride.pickup if ride.status is RideStatus.ACCEPTED else ride.dropoff
                view["distance_to_target_km"] = round(haversine_km(loc, target), 2)
        return view

    def cancel_ride(self, token: str, ride_id: str, reason: str = "") -> dict:
        user = self._customer(token)
        ride = self._ride(ride_id)
        self._check_owner(user, ride)
        if ride.status not in (RideStatus.SEARCHING, RideStatus.NO_DRIVER, RideStatus.ACCEPTED):
            raise StateError("Không thể hủy chuyến ở trạng thái hiện tại")
        if ride.driver:
            self._drivers[ride.driver].current_ride_id = None
        ride.offered_to = None
        ride.status = RideStatus.CANCELLED
        ride.cancelled_by = user.username
        ride.cancel_reason = reason
        ride.finished_at = self._now()
        self._log(user.username, "cancel", reason, ride)
        return self._ride_view(ride)

    def ride_history(self, token: str) -> list[dict]:
        user = self._customer(token)
        rides = [r for r in self._rides.values() if r.customer == user.username]
        return [self._ride_view(r) for r in sorted(rides, key=lambda r: (r.created_at, r.id), reverse=True)]

    def get_driver_contact(self, token: str, ride_id: str) -> dict:
        """Gọi tài xế: chỉ khả dụng từ lúc tài xế nhận chuyến đến khi kết thúc chuyến."""
        user = self._customer(token)
        ride = self._ride(ride_id)
        self._check_owner(user, ride)
        if ride.status not in (RideStatus.ACCEPTED, RideStatus.IN_PROGRESS) or not ride.driver:
            raise StateError("Chỉ gọi được tài xế từ khi tài xế nhận chuyến đến khi kết thúc chuyến")
        du = self._users[ride.driver]
        return {"name": du.full_name or du.username, "phone": du.phone,
                "plate": self._drivers[ride.driver].plate}

    @staticmethod
    def _check_stars(stars):
        if not isinstance(stars, int) or isinstance(stars, bool) or not 1 <= stars <= 5:
            raise ValidationError("Số sao phải từ 1 đến 5")

    def rate_driver(self, token: str, ride_id: str, stars: int, comment: str = "") -> dict:
        user = self._customer(token)
        ride = self._ride(ride_id)
        if ride.customer != user.username:
            raise PermissionDenied("Chỉ khách của chuyến mới được đánh giá")
        if ride.status is not RideStatus.COMPLETED:
            raise StateError("Chỉ đánh giá được chuyến đã hoàn thành")
        if ride.driver_rating:
            raise StateError("Chuyến này đã được đánh giá")
        self._check_stars(stars)
        ride.driver_rating = Rating(stars, comment, self._now())
        driver = self._users[ride.driver]
        driver.rating_sum += stars
        driver.rating_count += 1
        self._log(user.username, "rate_driver", f"{stars} sao", ride)
        return self._ride_view(ride)

    # ------------------------------------------------------------ tài xế
    def set_location(self, token: str, location: Location) -> None:
        user, dp = self._driver(token)
        dp.location = location

    def set_online(self, token: str, online: bool, location: Location | None = None) -> dict:
        """Bật/tắt nhận chuyến. Bật cần: được admin cấp quyền, ví >= mức tối thiểu, có vị trí."""
        user, dp = self._driver(token)
        if location:
            dp.location = location
        if online:
            if not dp.approved:
                raise PermissionDenied("Tài khoản tài xế chưa được admin cấp quyền hoạt động")
            if dp.wallet < self._min_wallet:
                raise StateError("Số dư ví không đủ, vui lòng nạp tiền để nhận chuyến")
            if dp.location is None:
                raise ValidationError("Cần cung cấp vị trí hiện tại để bật nhận chuyến")
            dp.online = True
        else:
            if dp.current_ride_id:
                raise StateError("Đang có chuyến, hãy hoàn thành hoặc hủy chuyến trước khi tắt")
            dp.online = False
            self._release_offers(dp.username, count_reject=False)
        self._log(user.username, "online" if dp.online else "offline")
        return self._user_view(user)

    def _release_offers(self, username: str, count_reject: bool):
        for ride in list(self._rides.values()):
            if ride.offered_to == username and ride.status is RideStatus.SEARCHING:
                ride.declined_by.add(username)
                if count_reject:
                    self._drivers[username].rejected_count += 1
                self._dispatch(ride)

    def get_wallet(self, token: str) -> dict:
        user, dp = self._driver(token)
        txs = [t.to_dict() for t in self._ledger if t.driver == user.username]
        return {"balance": dp.wallet, "transactions": txs}

    def _wallet_change(self, dp: DriverProfile, kind: str, amount: int, ride_id=None):
        dp.wallet += amount
        self._ledger.append(Transaction(len(self._ledger) + 1, dp.username, kind, amount,
                                        dp.wallet, self._now(), ride_id))

    def top_up(self, token: str, amount: int) -> dict:
        user, dp = self._driver(token)
        self._wallet_change(dp, "topup", self._money(amount))
        self._log(user.username, "topup", str(amount))
        return {"balance": dp.wallet}

    def withdraw(self, token: str, amount: int) -> dict:
        user, dp = self._driver(token)
        self._money(amount)
        if amount > dp.wallet:
            raise StateError("Số dư ví không đủ")
        self._wallet_change(dp, "withdraw", -amount)
        self._log(user.username, "withdraw", str(amount))
        return {"balance": dp.wallet}

    def list_offers(self, token: str) -> list[dict]:
        """Các yêu cầu đang chờ tài xế quyết định (điểm đi, điểm đến, giá cước...)."""
        user, dp = self._driver(token)
        out = []
        for r in self._rides.values():
            if r.offered_to == user.username and r.status is RideStatus.SEARCHING:
                commission = round(r.fare * self._commission_rate)
                out.append({
                    "ride_id": r.id, "pickup": r.pickup.to_dict(), "dropoff": r.dropoff.to_dict(),
                    "distance_km": r.distance_km, "fare": r.fare, "payment": r.payment.value,
                    "service": r.service.value, "estimated_net": r.fare - commission,
                    "pickup_distance_km": round(haversine_km(dp.location, r.pickup), 2)
                    if dp.location else None,
                })
        return out

    def accept_ride(self, token: str, ride_id: str) -> dict:
        user, dp = self._driver(token)
        ride = self._ride(ride_id)
        if ride.offered_to != user.username or ride.status is not RideStatus.SEARCHING:
            raise StateError("Chuyến không còn được đề nghị cho bạn")
        if not self._can_work(dp):
            raise StateError("Bạn chưa thể nhận chuyến (chưa bật hoạt động, đang có chuyến hoặc ví không đủ)")
        self._assign(ride, dp)
        self._log(user.username, "accept", ride=ride)
        return self._ride_view(ride)

    def reject_ride(self, token: str, ride_id: str) -> dict:
        user, dp = self._driver(token)
        ride = self._ride(ride_id)
        if ride.offered_to != user.username or ride.status is not RideStatus.SEARCHING:
            raise StateError("Chuyến không còn được đề nghị cho bạn")
        ride.declined_by.add(user.username)
        dp.rejected_count += 1
        self._log(user.username, "reject", ride=ride)
        self._dispatch(ride)
        return self._ride_view(ride)

    def driver_cancel_ride(self, token: str, ride_id: str, reason: str) -> dict:
        """Tài xế đổi ý sau khi đã nhận: chuyến được điều phối lại cho tài xế khác."""
        user, dp = self._driver(token)
        ride = self._ride(ride_id)
        if ride.driver != user.username or ride.status is not RideStatus.ACCEPTED:
            raise StateError("Chỉ hủy được chuyến đã nhận và chưa đón khách")
        if not reason or not reason.strip():
            raise ValidationError("Vui lòng nhập lý do hủy chuyến")
        dp.current_ride_id = None
        dp.cancelled_count += 1
        ride.driver = None
        ride.accepted_at = None
        ride.declined_by.add(user.username)
        self._log(user.username, "driver_cancel", reason.strip(), ride)
        self._dispatch(ride)
        return self._ride_view(ride)

    def start_ride(self, token: str, ride_id: str) -> dict:
        """Xác nhận khách đã lên xe, bắt đầu chuyến đi."""
        user, dp = self._driver(token)
        ride = self._ride(ride_id)
        if ride.driver != user.username or ride.status is not RideStatus.ACCEPTED:
            raise StateError("Không thể bắt đầu chuyến này")
        ride.status = RideStatus.IN_PROGRESS
        ride.started_at = self._now()
        self._log(user.username, "start", ride=ride)
        return self._ride_view(ride)

    def complete_ride(self, token: str, ride_id: str) -> dict:
        user, dp = self._driver(token)
        ride = self._ride(ride_id)
        if ride.driver != user.username or ride.status is not RideStatus.IN_PROGRESS:
            raise StateError("Không thể hoàn thành chuyến này")
        ride.status = RideStatus.COMPLETED
        ride.finished_at = self._now()
        ride.commission_rate = self._commission_rate
        ride.commission = int(round(ride.fare * self._commission_rate))
        ride.driver_net = ride.fare - ride.commission
        if ride.payment is PaymentMethod.CASH:      # tài xế đã thu tiền mặt -> trừ chiết khấu
            self._wallet_change(dp, "commission", -ride.commission, ride.id)
        else:                                       # khách trả qua app -> cộng phần của tài xế
            self._wallet_change(dp, "payout", ride.driver_net, ride.id)
        dp.current_ride_id = None
        dp.completed_count += 1
        dp.location = ride.dropoff
        self._log(user.username, "complete", f"fare={ride.fare} commission={ride.commission}", ride)
        return self._ride_view(ride)

    def current_ride(self, token: str) -> dict | None:
        user, dp = self._driver(token)
        return self._ride_view(self._rides[dp.current_ride_id]) if dp.current_ride_id else None

    def driver_history(self, token: str) -> list[dict]:
        user, _ = self._driver(token)
        rides = [r for r in self._rides.values() if r.driver == user.username]
        return [self._ride_view(r) for r in sorted(rides, key=lambda r: (r.created_at, r.id), reverse=True)]

    def driver_earnings(self, token: str, date_from: date | None = None,
                        date_to: date | None = None) -> dict:
        """Thu nhập ròng = tổng cước - chiết khấu của các chuyến hoàn thành."""
        user, _ = self._driver(token)
        rides = [r for r in self._rides.values() if r.driver == user.username
                 and r.status is RideStatus.COMPLETED
                 and self._in_range(r.finished_at, date_from, date_to)]
        gross = sum(r.fare for r in rides)
        commission = sum(r.commission for r in rides)
        return {"trips": len(rides), "gross": gross, "commission": commission,
                "net_income": gross - commission}

    def driver_stats(self, token: str) -> dict:
        user, dp = self._driver(token)
        offered = dp.accepted_count + dp.rejected_count
        return {
            "accepted": dp.accepted_count, "rejected": dp.rejected_count,
            "completed": dp.completed_count, "cancelled_after_accept": dp.cancelled_count,
            "completion_rate": round(dp.completed_count / dp.accepted_count, 4) if dp.accepted_count else None,
            "acceptance_rate": round(dp.accepted_count / offered, 4) if offered else None,
            "rating": user.avg_rating,
        }

    def rate_customer(self, token: str, ride_id: str, stars: int, comment: str = "") -> dict:
        user, _ = self._driver(token)
        ride = self._ride(ride_id)
        if ride.driver != user.username:
            raise PermissionDenied("Chỉ tài xế của chuyến mới được đánh giá")
        if ride.status is not RideStatus.COMPLETED:
            raise StateError("Chỉ đánh giá được chuyến đã hoàn thành")
        if ride.customer_rating:
            raise StateError("Chuyến này đã được đánh giá")
        self._check_stars(stars)
        ride.customer_rating = Rating(stars, comment, self._now())
        cust = self._users[ride.customer]
        cust.rating_sum += stars
        cust.rating_count += 1
        self._log(user.username, "rate_customer", f"{stars} sao", ride)
        return self._ride_view(ride)

    # ------------------------------------------------------------ điều phối
    def _assign(self, ride: Ride, dp: DriverProfile):
        ride.driver = dp.username
        ride.offered_to = None
        ride.status = RideStatus.ACCEPTED
        ride.accepted_at = self._now()
        dp.current_ride_id = ride.id
        dp.accepted_count += 1

    def _dispatch(self, ride: Ride):
        """Gửi đề nghị cho tài xế rảnh, đúng loại xe, gần điểm đón nhất."""
        ride.offered_to = None
        cands = []
        for dp in self._drivers.values():
            if (not self._can_work(dp) or dp.service_type is not ride.service
                    or dp.username in ride.declined_by or dp.username == ride.customer
                    or dp.location is None or self._has_pending_offer(dp.username)):
                continue
            d = haversine_km(dp.location, ride.pickup)
            if d <= self._max_pickup_km:
                cands.append((d, dp.username))
        if cands:
            _, chosen = min(cands)
            ride.offered_to = chosen
            ride.status = RideStatus.SEARCHING
            self._log("system", "offer", f"-> {chosen}", ride)
        else:
            ride.status = RideStatus.NO_DRIVER
            self._log("system", "no_driver", "", ride)

    # ------------------------------------------------------------ admin
    def list_users(self, token: str, role=None) -> list[dict]:
        self._admin(token)
        role = self._enum(Role, role, "Chức vụ") if role else None
        return [self._user_view(u) for u in self._users.values() if role is None or u.role is role]

    def approve_driver(self, token: str, username: str) -> dict:
        admin = self._admin(token)
        user = self._user(username)
        if user.role is not Role.DRIVER:
            raise ValidationError("Tài khoản này không phải tài xế")
        self._drivers[user.username].approved = True
        self._log(admin.username, "approve_driver", user.username)
        return self._user_view(user)

    def revoke_driver(self, token: str, username: str) -> dict:
        admin = self._admin(token)
        user = self._user(username)
        if user.role is not Role.DRIVER:
            raise ValidationError("Tài khoản này không phải tài xế")
        self._force_offline(user.username)
        self._drivers[user.username].approved = False
        self._log(admin.username, "revoke_driver", user.username)
        return self._user_view(user)

    def _force_offline(self, username: str):
        dp = self._drivers[username]
        dp.online = False
        self._release_offers(username, count_reject=False)

    def lock_user(self, token: str, username: str, reason: str = "") -> dict:
        admin = self._admin(token)
        user = self._user(username)
        if user.role is Role.ADMIN:
            raise PermissionDenied("Không thể khóa tài khoản admin")
        user.locked = True
        for t in [t for t, u in self._sessions.items() if u == user.username]:
            del self._sessions[t]
        if user.username in self._drivers:
            self._force_offline(user.username)
        self._log(admin.username, "lock_user", f"{user.username}: {reason}")
        return self._user_view(user)

    def unlock_user(self, token: str, username: str) -> dict:
        admin = self._admin(token)
        user = self._user(username)
        user.locked = False
        self._log(admin.username, "unlock_user", user.username)
        return self._user_view(user)

    def assign_ride(self, token: str, ride_id: str, driver_username: str) -> dict:
        """Gán chuyến trực tiếp cho một tài xế (bỏ qua bước đề nghị)."""
        admin = self._admin(token)
        ride = self._ride(ride_id)
        if ride.status not in (RideStatus.SEARCHING, RideStatus.NO_DRIVER):
            raise StateError("Chỉ gán được chuyến đang tìm tài xế")
        du = self._user(driver_username)
        dp = self._drivers.get(du.username)
        if dp is None:
            raise ValidationError("Tài khoản này không phải tài xế")
        if du.username == ride.customer:
            raise ValidationError("Không thể gán chuyến cho chính khách đặt")
        if not self._can_work(dp):
            raise StateError("Tài xế chưa sẵn sàng (chưa duyệt/chưa bật/đang bận/ví không đủ/bị khóa)")
        if dp.service_type is not ride.service:
            raise ValidationError("Loại xe của tài xế không khớp loại dịch vụ của chuyến")
        self._assign(ride, dp)
        self._log(admin.username, "assign", f"-> {du.username}", ride)
        return self._ride_view(ride)

    def get_pricing(self, token: str) -> dict:
        self._auth(token)
        return {s.value: {"base_fare": t.base_fare, "per_km": t.per_km, "min_fare": t.min_fare}
                for s, t in self._tariffs.items()}

    def set_price_per_km(self, token: str, service, price: int) -> dict:
        return self.update_tariff(token, service, per_km=price)

    def update_tariff(self, token: str, service, per_km: int | None = None,
                      base_fare: int | None = None, min_fare: int | None = None) -> dict:
        """Chỉ áp dụng cho chuyến đặt sau thời điểm thay đổi."""
        admin = self._admin(token)
        service = self._enum(ServiceType, service, "Loại dịch vụ")
        t = self._tariffs[service]
        for name, val in (("per_km", per_km), ("base_fare", base_fare), ("min_fare", min_fare)):
            if val is not None:
                if not isinstance(val, int) or isinstance(val, bool) or val < 0 or (name == "per_km" and val == 0):
                    raise ValidationError(f"Giá trị {name} không hợp lệ")
                setattr(t, name, val)
        self._log(admin.username, "update_tariff",
                  f"{service.value}: per_km={t.per_km} base={t.base_fare} min={t.min_fare}")
        return self.get_pricing(token)[service.value]

    def set_commission_rate(self, token: str, rate: float) -> float:
        admin = self._admin(token)
        if not isinstance(rate, (int, float)) or not 0 <= rate < 1:
            raise ValidationError("Tỷ lệ chiết khấu phải trong [0, 1)")
        self._commission_rate = float(rate)
        self._log(admin.username, "set_commission", str(rate))
        return self._commission_rate

    def revenue_report(self, token: str, date_from: date | None = None,
                       date_to: date | None = None) -> dict:
        """Thống kê doanh thu theo các chuyến hoàn thành (tính theo ngày kết thúc)."""
        self._admin(token)
        done = [r for r in self._rides.values() if r.status is RideStatus.COMPLETED
                and self._in_range(r.finished_at, date_from, date_to)]
        others = [r for r in self._rides.values() if r.status in (RideStatus.CANCELLED, RideStatus.NO_DRIVER)
                  and self._in_range(r.finished_at or r.created_at, date_from, date_to)]

        def group(key):
            out: dict = {}
            for r in done:
                g = out.setdefault(key(r), {"trips": 0, "gross": 0, "commission": 0})
                g["trips"] += 1
                g["gross"] += r.fare
                g["commission"] += r.commission
            return out

        gross = sum(r.fare for r in done)
        commission = sum(r.commission for r in done)
        return {"completed_trips": len(done),
                "cancelled_trips": sum(r.status is RideStatus.CANCELLED for r in others),
                "no_driver_trips": sum(r.status is RideStatus.NO_DRIVER for r in others),
                "gross_revenue": gross, "platform_commission": commission,
                "driver_payout": gross - commission,
                "by_service": group(lambda r: r.service.value),
                "by_payment": group(lambda r: r.payment.value),
                "by_day": group(lambda r: r.finished_at.date().isoformat())}

    def search_rides(self, token: str, status=None, customer: str | None = None,
                     driver: str | None = None, date_from: date | None = None,
                     date_to: date | None = None) -> list[dict]:
        self._admin(token)
        status = self._enum(RideStatus, status, "Trạng thái") if status else None
        out = []
        for r in self._rides.values():
            if status and r.status is not status:
                continue
            if customer and r.customer != customer.strip().lower():
                continue
            if driver and r.driver != driver.strip().lower():
                continue
            if (date_from or date_to) and not self._in_range(r.created_at, date_from, date_to):
                continue
            out.append(self._ride_view(r))
        return sorted(out, key=lambda v: (v["created_at"], v["id"]), reverse=True)

    def audit_ride(self, token: str, ride_id: str) -> dict:
        """Tra soát một chuyến: dòng thời gian, giao dịch ví và kiểm tra tính nhất quán."""
        self._admin(token)
        ride = self._ride(ride_id)
        txs = [t for t in self._ledger if t.ride_id == ride.id]
        issues = []
        if ride.status is RideStatus.COMPLETED:
            if ride.commission + ride.driver_net != ride.fare:
                issues.append("Chiết khấu + thu nhập tài xế != giá cước")
            if ride.commission != int(round(ride.fare * ride.commission_rate)):
                issues.append("Chiết khấu không khớp tỷ lệ đã áp dụng")
            expected = -ride.commission if ride.payment is PaymentMethod.CASH else ride.driver_net
            if len(txs) != 1:
                issues.append(f"Số giao dịch ví là {len(txs)} (kỳ vọng 1)")
            elif txs[0].amount != expected:
                issues.append(f"Giao dịch ví {txs[0].amount} != kỳ vọng {expected}")
        elif txs:
            issues.append("Chuyến chưa hoàn thành nhưng có giao dịch ví")
        if ride.status in (RideStatus.ACCEPTED, RideStatus.IN_PROGRESS, RideStatus.COMPLETED) and not ride.driver:
            issues.append("Thiếu tài xế")
        timeline = [e.to_dict() for e in self._audit if e.ride_id == ride.id]
        return {"ride": self._ride_view(ride), "timeline": timeline,
                "transactions": [t.to_dict() for t in txs],
                "issues": issues, "consistent": not issues}

    def get_notifications(self, token: str, unread_only: bool = False) -> list[dict]:
        """Xem hộp thông báo của tài khoản đang đăng nhập; đánh dấu đã đọc."""
        user = self._auth(token)
        items = [n for n in self._notifications
                 if n["recipient"] == user.username and (not unread_only or not n["read"])]
        for item in items:
            item["read"] = True
        return [dict(item) for item in items]

    def audit_log(self, token: str, limit: int = 100) -> list[dict]:
        self._admin(token)
        return [e.to_dict() for e in self._audit[-limit:]]

    def reconcile_wallets(self, token: str) -> dict:
        """Đối soát: số dư ví từng tài xế phải bằng tổng các giao dịch."""
        self._admin(token)
        mismatches = []
        for u, dp in self._drivers.items():
            total = sum(t.amount for t in self._ledger if t.driver == u)
            if total != dp.wallet:
                mismatches.append({"driver": u, "wallet": dp.wallet, "ledger_total": total})
        return {"checked": len(self._drivers), "ok": not mismatches, "mismatches": mismatches}
