"""Kịch bản demo chạy tự động toàn bộ luồng chính."""
from .models import Location
from .places import PLACES
from .system import DispatchSystem


def run_demo(out=print):
    s = DispatchSystem()
    step = lambda t: out(f"\n--- {t}")
    s.register("admin", "admin123", "admin", "Quản trị viên", admin_code="ADMIN2026")
    s.register("lan", "matkhau1", "customer", "Lê Lan", "0912345678", "lan@mail.com")
    s.register("hung", "matkhau1", "driver", "Phạm Hùng", "0987654321", service_type="car4", plate="30A-123.45")
    admin, lan, hung = (s.login(u, p)["token"] for u, p in
                        [("admin", "admin123"), ("lan", "matkhau1"), ("hung", "matkhau1")])

    step("Admin cấp quyền cho tài xế; tài xế nạp ví và bật nhận chuyến")
    s.approve_driver(admin, "hung")
    s.top_up(hung, 100_000)
    s.set_online(hung, True, PLACES["Hồ Gươm"])

    step("Khách xem giá cước các dịch vụ")
    pickup, drop = PLACES["Hồ Gươm"], PLACES["Bến xe Mỹ Đình"]
    for q in s.quote_fare(lan, pickup, drop):
        out(f"  {q['service']}: {q['distance_km']} km -> {q['fare']:,}đ")

    step("Khách đặt xe car4, trả tiền mặt")
    ride = s.book_ride(lan, pickup, drop, "car4", "cash")
    out(f"  {ride['id']} - {ride['status_label']}")

    step("Tài xế thấy yêu cầu và chấp nhận")
    out("  offers:", s.list_offers(hung)[0])
    s.accept_ride(hung, ride["id"])
    out("  khách gọi tài xế:", s.get_driver_contact(lan, ride["id"]))
    s.set_location(hung, Location("Gần điểm đón", 21.0290, 105.8500))
    out("  theo dõi:", s.track_ride(lan, ride["id"])["distance_to_target_km"], "km tới điểm đón")

    step("Bắt đầu và hoàn thành chuyến")
    s.start_ride(hung, ride["id"])
    done = s.complete_ride(hung, ride["id"])
    out(f"  cước {done['fare']:,}đ, chiết khấu {done['commission']:,}đ, tài xế nhận {done['driver_net']:,}đ")
    out("  ví tài xế:", s.get_wallet(hung)["balance"])

    step("Đánh giá hai chiều")
    s.rate_driver(lan, ride["id"], 5, "Lái xe tốt")
    s.rate_customer(hung, ride["id"], 5, "Khách lịch sự")
    out("  tài xế:", s.driver_stats(hung))

    step("Admin chỉnh giá, xem doanh thu và tra soát")
    s.set_price_per_km(admin, "car4", 10_000)
    out("  doanh thu:", s.revenue_report(admin))
    out("  tra soát:", s.audit_ride(admin, ride["id"])["consistent"], s.reconcile_wallets(admin))
