"""Giao diện console: menu Đăng ký / Đăng nhập rồi menu theo chức vụ."""
from __future__ import annotations

from datetime import date

from .errors import DispatchError
from .models import Location
from .places import PLACES

SERVICES = ["bike", "car4", "car7"]
PAYMENTS = [("cash", "Tiền mặt"), ("card", "Thẻ"), ("e_wallet", "Ví điện tử")]
ROLES = {"1": "customer", "2": "driver", "3": "admin"}
vnd = lambda n: f"{n:,}đ".replace(",", ".")


class ConsoleApp:
    def __init__(self, system, input_fn=input, print_fn=print):
        self.s, self.inp, self.out = system, input_fn, print_fn
        self.token = None
        self.user = None

    # ---- tiện ích nhập/xuất
    def ask(self, label: str) -> str:
        return self.inp(f"{label}: ").strip()

    def choose(self, title: str, options: list[str]) -> int | None:
        self.out(f"\n== {title} ==")
        for i, o in enumerate(options, 1):
            self.out(f"  {i}. {o}")
        self.out("  0. Quay lại / Thoát")
        v = self.ask("Chọn")
        return int(v) - 1 if v.isdigit() and 1 <= int(v) <= len(options) else None

    def pick_place(self, label: str) -> Location:
        names = list(PLACES)
        i = self.choose(label, names + ["Nhập toạ độ thủ công"])
        if i is None:
            raise DispatchError("Đã hủy")
        if i < len(names):
            return PLACES[names[i]]
        lat, lng = self.ask("Vĩ độ,kinh độ (vd 21.03,105.85)").split(",")
        return Location(self.ask("Tên địa điểm"), float(lat), float(lng))

    def pick(self, title, items):
        i = self.choose(title, items)
        if i is None:
            raise DispatchError("Đã hủy")
        return i

    def show(self, d):
        if isinstance(d, dict):
            for k, v in d.items():
                self.out(f"   {k}: {v}")
        else:
            for x in d:
                self.show(x) if isinstance(x, dict) else self.out(f"   {x}")
                self.out("   --")

    def run_action(self, fn):
        try:
            fn()
        except (DispatchError, ValueError) as e:
            self.out(f"[Lỗi] {e}")

    # ---- vòng lặp chính
    def run(self):
        while True:
            c = self.choose("RIDE-SHARING DISPATCH", ["Đăng ký", "Đăng nhập"])
            if c is None:
                self.out("Tạm biệt!")
                return
            self.run_action(self.register if c == 0 else self.login)
            if self.token:
                self.session()

    def register(self):
        uname, pw = self.ask("Tên đăng nhập"), self.ask("Mật khẩu")
        r = self.ask("Chức vụ (1=Khách hàng, 2=Tài xế, 3=Admin)")
        if r not in ROLES:
            raise DispatchError("Chức vụ không hợp lệ")
        kw = dict(full_name=self.ask("Họ và tên"), phone=self.ask("Số điện thoại"), email=self.ask("Email"))
        if ROLES[r] == "driver":
            kw.update(service_type=SERVICES[self.pick("Loại xe", SERVICES)], plate=self.ask("Biển số"))
        if ROLES[r] == "admin":
            kw["admin_code"] = self.ask("Mã xác thực admin")
        self.s.register(uname, pw, ROLES[r], **kw)
        self.out("Đăng ký thành công. Hãy đăng nhập." + (
            " Tài khoản tài xế cần admin cấp quyền hoạt động." if ROLES[r] == "driver" else ""))

    def login(self):
        res = self.s.login(self.ask("Tên đăng nhập"), self.ask("Mật khẩu"))
        self.token, self.user = res["token"], res["user"]
        self.out(f"Xin chào {self.user['full_name'] or self.user['username']} ({self.user['role']})")

    def session(self):
        role = self.user["role"]
        sections = {"customer": [("Khách hàng", self.customer_menu)],
                    "driver": [("Tài xế", self.driver_menu)],
                    "admin": [("Quản trị", self.admin_menu), ("Chức năng khách hàng", self.customer_menu),
                              ("Chức năng tài xế", self.driver_menu)]}[role]
        while self.token:
            c = self.choose("MENU CHÍNH", [n for n, _ in sections] + ["Thông tin cá nhân", "Đổi mật khẩu", "Thông báo lỗi", "Đăng xuất"])
            if c is None:
                break
            if c < len(sections):
                sections[c][1]()
            elif c == len(sections):
                self.run_action(self.profile)
            elif c == len(sections) + 1:
                self.run_action(self.password)
            elif c == len(sections) + 2:
                self.run_action(lambda: self.show(self.s.get_notifications(self.token)))
            else:
                break
        self.s.logout(self.token)
        self.token = self.user = None

    # ---- chung
    def profile(self):
        self.show(self.s.get_profile(self.token))
        if self.ask("Chỉnh sửa? (y/n)").lower() == "y":
            self.show(self.s.update_profile(
                self.token, full_name=self.ask("Họ và tên"), phone=self.ask("Số điện thoại"), email=self.ask("Email")))

    def password(self):
        self.s.change_password(self.token, self.ask("Mật khẩu cũ"), self.ask("Mật khẩu mới"), self.ask("Nhập lại mật khẩu mới"))
        self.out("Đã đổi mật khẩu")

    def menu(self, title, items):
        while True:
            c = self.choose(title, [n for n, _ in items])
            if c is None:
                return
            self.run_action(items[c][1])

    # ---- khách hàng
    def customer_menu(self):
        ride_id = lambda: self.ask("Mã chuyến (vd R0001)")
        self.menu("KHÁCH HÀNG", [
            ("Đặt xe", self.book),
            ("Theo dõi trạng thái & vị trí", lambda: self.show(self.s.track_ride(self.token, ride_id()))),
            ("Gọi tài xế", lambda: self.show(self.s.get_driver_contact(self.token, ride_id()))),
            ("Hủy chuyến", lambda: self.show(self.s.cancel_ride(self.token, ride_id(), self.ask("Lý do")))),
            ("Lịch sử chuyến", lambda: self.show(self.s.ride_history(self.token))),
            ("Đánh giá tài xế", lambda: self.show(self.s.rate_driver(self.token, ride_id(), int(self.ask("Số sao 1-5")), self.ask("Nhận xét")))),
            ("Tìm lại tài xế", lambda: self.show(self.s.retry_search(self.token, ride_id()))),
        ])

    def book(self):
        pickup, drop = self.pick_place("Điểm đón"), self.pick_place("Điểm đến")
        quotes = self.s.quote_fare(self.token, pickup, drop)
        self.out(f"Quãng đường: {quotes[0]['distance_km']} km")
        i = self.pick("Chọn loại dịch vụ", [f"{q['service']} - {vnd(q['fare'])}" for q in quotes])
        p = self.pick("Phương thức thanh toán", [n for _, n in PAYMENTS])
        if self.ask("Xác nhận đặt chuyến? (y/n)").lower() != "y":
            return
        customer = None
        if self.user["role"] == "admin":
            customer = self.ask("Đặt hộ khách (bỏ trống = cho chính mình)") or None
        self.show(self.s.book_ride(self.token, pickup, drop, quotes[i]["service"], PAYMENTS[p][0], customer))

    # ---- tài xế
    def driver_menu(self):
        ride_id = lambda: self.ask("Mã chuyến")
        self.menu("TÀI XẾ", [
            ("Bật hoạt động (nhận chuyến)", lambda: self.show(self.s.set_online(self.token, True, self.pick_place("Vị trí hiện tại")))),
            ("Tắt hoạt động", lambda: self.show(self.s.set_online(self.token, False))),
            ("Xem yêu cầu chuyến", lambda: self.show(self.s.list_offers(self.token))),
            ("Chấp nhận chuyến", lambda: self.show(self.s.accept_ride(self.token, ride_id()))),
            ("Từ chối chuyến", lambda: self.show(self.s.reject_ride(self.token, ride_id()))),
            ("Khách đã lên xe - bắt đầu", lambda: self.show(self.s.start_ride(self.token, ride_id()))),
            ("Hoàn thành chuyến", lambda: self.show(self.s.complete_ride(self.token, ride_id()))),
            ("Hủy chuyến đã nhận", lambda: self.show(self.s.driver_cancel_ride(self.token, ride_id(), self.ask("Lý do")))),
            ("Ví (xem / nạp / rút)", self.wallet),
            ("Lịch sử chuyến", lambda: self.show(self.s.driver_history(self.token))),
            ("Thu nhập ròng", lambda: self.show(self.s.driver_earnings(self.token))),
            ("Tỷ lệ hoàn thành chuyến", lambda: self.show(self.s.driver_stats(self.token))),
            ("Đánh giá khách", lambda: self.show(self.s.rate_customer(self.token, ride_id(), int(self.ask("Số sao 1-5")), self.ask("Nhận xét")))),
        ])

    def wallet(self):
        c = self.pick("Ví", ["Xem số dư & giao dịch", "Nạp tiền", "Rút tiền"])
        if c == 0:
            self.show(self.s.get_wallet(self.token))
        else:
            amt = int(self.ask("Số tiền"))
            self.show((self.s.top_up if c == 1 else self.s.withdraw)(self.token, amt))

    # ---- admin
    def admin_menu(self):
        user = lambda: self.ask("Tên tài khoản")
        d = lambda t: (lambda v: date.fromisoformat(v) if v else None)(self.ask(t))
        self.menu("ADMIN", [
            ("Danh sách tài khoản", lambda: self.show(self.s.list_users(self.token))),
            ("Cấp quyền hoạt động cho tài xế", lambda: self.show(self.s.approve_driver(self.token, user()))),
            ("Thu hồi quyền tài xế", lambda: self.show(self.s.revoke_driver(self.token, user()))),
            ("Khóa tài khoản", lambda: self.show(self.s.lock_user(self.token, user(), self.ask("Lý do")))),
            ("Mở khóa tài khoản", lambda: self.show(self.s.unlock_user(self.token, user()))),
            ("Gán chuyến cho tài xế", lambda: self.show(self.s.assign_ride(self.token, self.ask("Mã chuyến"), user()))),
            ("Xem bảng giá", lambda: self.show(self.s.get_pricing(self.token))),
            ("Chỉnh giá / km", lambda: self.show(self.s.set_price_per_km(self.token, SERVICES[self.pick("Dịch vụ", SERVICES)], int(self.ask("Giá mỗi km (VND)"))))),
            ("Thống kê doanh thu", lambda: self.show(self.s.revenue_report(self.token, d("Từ ngày YYYY-MM-DD (bỏ trống = tất cả)"), d("Đến ngày")))),
            ("Tra soát chuyến", lambda: self.show(self.s.audit_ride(self.token, self.ask("Mã chuyến")))),
            ("Tìm kiếm chuyến", lambda: self.show(self.s.search_rides(self.token, status=self.ask("Trạng thái (bỏ trống = tất cả)") or None))),
            ("Đối soát ví tài xế", lambda: self.show(self.s.reconcile_wallets(self.token))),
            ("Nhật ký hệ thống", lambda: self.show(self.s.audit_log(self.token, 30))),
        ])
