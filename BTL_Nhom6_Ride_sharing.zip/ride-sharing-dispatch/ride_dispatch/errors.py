"""Các ngoại lệ nghiệp vụ của hệ thống."""


class DispatchError(Exception):
    """Lỗi gốc của hệ thống."""


class ValidationError(DispatchError):
    """Dữ liệu đầu vào không hợp lệ."""


class AuthError(DispatchError):
    """Chưa đăng nhập / sai thông tin đăng nhập / phiên hết hạn."""


class PermissionDenied(DispatchError):
    """Không đủ quyền hoặc tài khoản bị khóa."""


class NotFound(DispatchError):
    """Không tìm thấy đối tượng."""


class StateError(DispatchError):
    """Thao tác không hợp lệ với trạng thái hiện tại."""
