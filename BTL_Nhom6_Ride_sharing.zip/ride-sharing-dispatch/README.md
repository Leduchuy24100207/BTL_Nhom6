# Ride-Sharing Dispatch System (backend demo)

Backend Python thuần (không cần thư viện ngoài), dữ liệu lưu trong bộ nhớ.

    python main.py          # menu console: Đăng ký / Đăng nhập, rồi menu theo chức vụ
    python main.py --demo   # kịch bản demo tự động
    pip install pytest && pytest

- Mã xác thực khi đăng ký admin: `ADMIN2026` (đổi qua `DispatchSystem(admin_code=...)`).
- Tài xế đăng ký xong phải được admin cấp quyền mới bật nhận chuyến được; ví phải >= 0.
- Thanh toán tiền mặt: ví tài xế bị trừ chiết khấu (mặc định 20%). Thanh toán thẻ/ví điện tử: ví được cộng (cước - chiết khấu).
- Admin dùng được cả chức năng khách (đặt xe) và tài xế (nhận chuyến, ví) với cùng tài khoản.
- Lõi nghiệp vụ: `ride_dispatch/system.py` (lớp `DispatchSystem`).

- **Thông báo lỗi:** khi thao tác nghiệp vụ phát sinh `DispatchError`, hệ thống lưu thông báo vào hộp thư trong ứng dụng và ghi nhật ký. Nếu tài khoản gây lỗi là admin, chỉ admin đó nhận; nếu là khách hàng/tài xế, người đó và tất cả admin đã đăng ký nhận. Đăng nhập rồi chọn **Thông báo lỗi** để xem (thông báo được đánh dấu đã đọc). Đây là thông báo nội bộ trong bộ nhớ, chưa phải SMS/email/push và sẽ mất khi chương trình khởi động lại.
