"""Chạy:  python main.py          -> menu console (đăng ký / đăng nhập)
         python main.py --demo   -> kịch bản demo tự động"""
import sys

from ride_dispatch.cli import ConsoleApp
from ride_dispatch.demo import run_demo
from ride_dispatch.system import DispatchSystem

if __name__ == "__main__":
    if "--demo" in sys.argv:
        run_demo()
    else:
        ConsoleApp(DispatchSystem()).run()
