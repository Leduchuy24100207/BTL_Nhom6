import pytest

from ride_dispatch import PermissionDenied, StateError, ValidationError
from conftest import HOAN_KIEM, VAN_MIEU, book, new_driver


def finish(w, ride_id, tok=None):
    tok = tok or w.binh
    w.s.accept_ride(tok, ride_id)
    w.s.start_ride(tok, ride_id)
    return w.s.complete_ride(tok, ride_id)


def test_cash_ride_deducts_commission(world):
    ride = finish(world, book(world, "cash")["id"])
    assert ride["status"] == "completed"
    assert ride["commission"] == round(ride["fare"] * 0.2)
    assert world.s.get_wallet(world.binh)["balance"] == 100_000 - ride["commission"]


def test_app_payment_credits_net(world):
    ride = finish(world, book(world, "e_wallet")["id"])
    assert world.s.get_wallet(world.binh)["balance"] == 100_000 + ride["fare"] - ride["commission"]


def test_unapproved_driver_cannot_go_online(world):
    s = world.s
    s.register("moi", "secret1", "driver")
    tok = s.login("moi", "secret1")["token"]
    with pytest.raises(PermissionDenied):
        s.set_online(tok, True, HOAN_KIEM)


def test_online_requires_location_and_wallet(world):
    s = world.s
    s.register("moi", "secret1", "driver")
    tok = s.login("moi", "secret1")["token"]
    s.approve_driver(world.admin, "moi")
    with pytest.raises(ValidationError):
        s.set_online(tok, True)
    # ví âm sau chuyến tiền mặt -> không bật lại được
    s.register("ngheo", "secret1", "driver")
    nt = s.login("ngheo", "secret1")["token"]
    s.approve_driver(world.admin, "ngheo")
    s.set_online(nt, True, HOAN_KIEM)
    ride = book(world)  # offer cho 1 trong 2 tài xế
    tok_owner = world.binh if s.list_offers(world.binh) else nt
    finish(world, ride["id"], tok_owner)
    if tok_owner == nt:
        s.set_online(nt, False)
        with pytest.raises(StateError):
            s.set_online(nt, True)
        s.top_up(nt, 50_000)
        s.set_online(nt, True)


def test_offline_driver_gets_no_offers(world):
    world.s.set_online(world.binh, False)
    assert book(world)["status"] == "no_driver"


def test_cannot_go_offline_during_ride(world):
    ride = book(world)
    world.s.accept_ride(world.binh, ride["id"])
    with pytest.raises(StateError):
        world.s.set_online(world.binh, False)


def test_going_offline_redirects_pending_offer(world):
    other = new_driver(world, "cuong", VAN_MIEU)
    ride = book(world)
    world.s.set_online(world.binh, False)
    assert world.s.list_offers(other)[0]["ride_id"] == ride["id"]
    assert world.s.driver_stats(world.binh)["rejected"] == 0


def test_accept_requires_offer(world):
    other = new_driver(world, "cuong", VAN_MIEU)
    ride = book(world)
    with pytest.raises(StateError):
        world.s.accept_ride(other, ride["id"])


def test_start_and_complete_order(world):
    ride = book(world)
    with pytest.raises(StateError):
        world.s.start_ride(world.binh, ride["id"])       # chưa nhận
    world.s.accept_ride(world.binh, ride["id"])
    with pytest.raises(StateError):
        world.s.complete_ride(world.binh, ride["id"])    # chưa bắt đầu


def test_driver_cancel_after_accept_redispatches_and_hits_rate(world):
    s = world.s
    other = new_driver(world, "cuong", VAN_MIEU)
    r1 = book(world)
    s.accept_ride(world.binh, r1["id"])
    with pytest.raises(ValidationError):
        s.driver_cancel_ride(world.binh, r1["id"], " ")
    res = s.driver_cancel_ride(world.binh, r1["id"], "xe hỏng")
    assert res["status"] == "searching" and res["driver"] is None
    assert s.list_offers(other)                            # chuyển cho tài xế khác
    assert not s.list_offers(world.binh)                   # không đề nghị lại cho người đã hủy
    # binh hoàn thành 1 chuyến khác -> tỷ lệ hoàn thành = 1/2
    s.accept_ride(other, r1["id"]); s.start_ride(other, r1["id"]); s.complete_ride(other, r1["id"])
    world.clock.advance(minutes=30)
    r2 = book(world)
    finish(world, r2["id"])
    st = s.driver_stats(world.binh)
    assert st["accepted"] == 2 and st["completed"] == 1 and st["cancelled_after_accept"] == 1
    assert st["completion_rate"] == 0.5


def test_acceptance_rate(world):
    s = world.s
    r1 = book(world)
    s.reject_ride(world.binh, r1["id"])
    s.retry_search(world.an, r1["id"])
    assert s.driver_stats(world.binh)["acceptance_rate"] == 0.0
    s.accept_ride(world.binh, r1["id"])
    assert s.driver_stats(world.binh)["acceptance_rate"] == 0.5


def test_earnings_and_history(world):
    s = world.s
    r1 = finish(world, book(world, "cash")["id"])
    world.clock.advance(minutes=20)
    r2 = finish(world, book(world, "card")["id"])
    e = s.driver_earnings(world.binh)
    assert e["trips"] == 2
    assert e["gross"] == r1["fare"] + r2["fare"]
    assert e["net_income"] == e["gross"] - e["commission"]
    assert [r["id"] for r in s.driver_history(world.binh)] == [r2["id"], r1["id"]]


def test_rate_customer(world):
    s = world.s
    ride = finish(world, book(world)["id"])
    s.rate_customer(world.binh, ride["id"], 5, "lịch sự")
    with pytest.raises(StateError):
        s.rate_customer(world.binh, ride["id"], 4)
    assert s.get_profile(world.an)["rating"] == 5.0


def test_wallet_topup_withdraw(world):
    s = world.s
    s.withdraw(world.binh, 40_000)
    assert s.get_wallet(world.binh)["balance"] == 60_000
    with pytest.raises(StateError):
        s.withdraw(world.binh, 1_000_000)
    with pytest.raises(ValidationError):
        s.top_up(world.binh, -5)
    kinds = [t["kind"] for t in s.get_wallet(world.binh)["transactions"]]
    assert kinds == ["topup", "withdraw"]
