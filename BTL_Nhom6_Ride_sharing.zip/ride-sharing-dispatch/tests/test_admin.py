from datetime import date

import pytest

from ride_dispatch import PermissionDenied, StateError, ValidationError, AuthError
from conftest import HOAN_KIEM, MY_DINH, book, new_driver
from test_driver_flow import finish


def test_approve_and_revoke_driver(world):
    s = world.s
    s.register("moi", "secret1", "driver")
    tok = s.login("moi", "secret1")["token"]
    s.approve_driver(world.admin, "moi")
    s.set_online(tok, True, HOAN_KIEM)
    s.revoke_driver(world.admin, "moi")
    assert s.get_profile(tok)["online"] is False and s.get_profile(tok)["approved"] is False
    with pytest.raises(ValidationError):
        s.approve_driver(world.admin, "anh")      # không phải tài xế


def test_lock_customer_and_driver(world):
    s = world.s
    s.lock_user(world.admin, "anh", "vi phạm")
    with pytest.raises(AuthError):
        s.get_profile(world.an)                  # phiên bị hủy
    with pytest.raises(PermissionDenied):
        s.login("anh", "secret1")
    s.unlock_user(world.admin, "anh")
    s.login("anh", "secret1")
    s.lock_user(world.admin, "binh")
    assert book(world, token=s.login("anh", "secret1")["token"])["status"] == "no_driver"
    with pytest.raises(PermissionDenied):
        s.lock_user(world.admin, "admin")


def test_admin_books_for_customer_and_assigns(world):
    s = world.s
    s.set_online(world.binh, False)
    ride = s.book_ride(world.admin, HOAN_KIEM, MY_DINH, "car4", "cash", customer_username="anh")
    assert ride["customer"] == "anh" and ride["booked_by"] == "admin"
    assert ride["status"] == "no_driver"
    with pytest.raises(StateError):
        s.assign_ride(world.admin, ride["id"], "binh")   # tài xế đang tắt
    s.set_online(world.binh, True)
    res = s.assign_ride(world.admin, ride["id"], "binh")
    assert res["status"] == "accepted" and res["driver"] == "binh"
    assert s.get_driver_contact(world.an, ride["id"])["name"] == "Trần Bình"


def test_customer_cannot_book_for_others(world):
    world.s.register("chi", "secret1", "customer")
    with pytest.raises(PermissionDenied):
        world.s.book_ride(world.an, HOAN_KIEM, MY_DINH, "car4", "cash", customer_username="chi")


def test_assign_service_mismatch(world):
    new_driver(world, "xe_may", HOAN_KIEM, "bike")
    ride = book(world, service="car4")
    world.s.cancel_ride(world.an, ride["id"])
    world.s.set_online(world.binh, False)
    ride = book(world, service="car4")
    with pytest.raises(ValidationError):
        world.s.assign_ride(world.admin, ride["id"], "xe_may")


def test_admin_has_customer_and_driver_features(world):
    s = world.s
    # admin làm khách
    ride = s.book_ride(world.admin, HOAN_KIEM, MY_DINH, "car4", "cash")
    assert ride["customer"] == "admin"
    s.cancel_ride(world.admin, ride["id"])
    # admin làm tài xế
    s.top_up(world.admin, 50_000)
    s.set_online(world.admin, True, HOAN_KIEM)
    s.set_online(world.binh, False)
    r2 = book(world)
    s.accept_ride(world.admin, r2["id"]); s.start_ride(world.admin, r2["id"]); s.complete_ride(world.admin, r2["id"])
    assert s.driver_earnings(world.admin)["trips"] == 1
    s.update_profile(world.admin, full_name="Admin Mới")


def test_price_per_km_change_affects_new_rides_only(world):
    s = world.s
    before = book(world)
    s.cancel_ride(world.an, before["id"])
    s.set_price_per_km(world.admin, "car4", 20_000)
    after = book(world)
    assert after["fare"] > before["fare"]
    assert s.get_pricing(world.an)["car4"]["per_km"] == 20_000
    assert s.ride_history(world.an)[-1]["fare"] == before["fare"]   # chuyến cũ giữ nguyên giá
    with pytest.raises(ValidationError):
        s.set_price_per_km(world.admin, "car4", 0)
    with pytest.raises(ValidationError):
        s.set_price_per_km(world.admin, "tau_vu_tru", 1000)


def test_revenue_report(world):
    s = world.s
    r1 = finish(world, book(world, "cash")["id"])
    world.clock.advance(days=1)
    r2 = finish(world, book(world, "card")["id"])
    c = book(world); s.cancel_ride(world.an, c["id"])
    rep = s.revenue_report(world.admin)
    assert rep["completed_trips"] == 2 and rep["cancelled_trips"] == 1
    assert rep["gross_revenue"] == r1["fare"] + r2["fare"]
    assert rep["platform_commission"] + rep["driver_payout"] == rep["gross_revenue"]
    assert set(rep["by_day"]) == {"2026-10-20", "2026-10-21"}
    assert rep["by_payment"]["cash"]["trips"] == 1
    one_day = s.revenue_report(world.admin, date(2026, 10, 21), date(2026, 10, 21))
    assert one_day["completed_trips"] == 1 and one_day["gross_revenue"] == r2["fare"]


def test_commission_rate_change(world):
    world.s.set_commission_rate(world.admin, 0.1)
    ride = finish(world, book(world)["id"])
    assert ride["commission"] == round(ride["fare"] * 0.1)
    with pytest.raises(ValidationError):
        world.s.set_commission_rate(world.admin, 1.5)


def test_audit_and_reconcile(world):
    s = world.s
    ride = finish(world, book(world, "cash")["id"])
    audit = s.audit_ride(world.admin, ride["id"])
    assert audit["consistent"] and len(audit["transactions"]) == 1
    actions = [e["action"] for e in audit["timeline"]]
    assert actions == ["book", "offer", "accept", "start", "complete"]
    assert s.reconcile_wallets(world.admin)["ok"]
    # giả lập sai lệch ví để kiểm tra tra soát phát hiện được
    s._drivers["binh"].wallet += 999
    assert not s.reconcile_wallets(world.admin)["ok"]
    s._rides[ride["id"]].commission += 1
    assert not s.audit_ride(world.admin, ride["id"])["consistent"]


def test_search_rides_and_audit_log(world):
    s = world.s
    finish(world, book(world)["id"])
    c = book(world); s.cancel_ride(world.an, c["id"])
    assert len(s.search_rides(world.admin)) == 2
    assert len(s.search_rides(world.admin, status="cancelled")) == 1
    assert len(s.search_rides(world.admin, driver="binh")) == 1
    assert len(s.search_rides(world.admin, customer="anh")) == 2
    log = s.audit_log(world.admin)
    assert any(e["action"] == "complete" for e in log)


def test_list_users_filter(world):
    assert [u["username"] for u in world.s.list_users(world.admin, "driver")] == ["binh"]
    assert len(world.s.list_users(world.admin)) == 3
