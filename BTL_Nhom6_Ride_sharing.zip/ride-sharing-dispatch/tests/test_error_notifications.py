def test_customer_error_notifies_customer_and_admin(world):
    from ride_dispatch.errors import PermissionDenied

    try:
        world.s.set_price_per_km(world.an, "car4", 1000)
    except PermissionDenied:
        pass
    else:
        assert False, "customer should not be allowed to change pricing"

    customer_notes = world.s.get_notifications(world.an)
    admin_notes = world.s.get_notifications(world.admin)
    assert any(n["source"] == "set_price_per_km" for n in customer_notes)
    assert any(n["source"] == "set_price_per_km" for n in admin_notes)


def test_admin_error_notifies_only_admin(world):
    from ride_dispatch.errors import NotFound

    try:
        world.s.lock_user(world.admin, "missing_user", "test")
    except NotFound:
        pass
    else:
        assert False, "unknown user should raise NotFound"

    assert any(n["source"] == "lock_user" for n in world.s.get_notifications(world.admin))
    assert not any(n["source"] == "lock_user" for n in world.s.get_notifications(world.an))
    assert not any(n["source"] == "lock_user" for n in world.s.get_notifications(world.binh))
