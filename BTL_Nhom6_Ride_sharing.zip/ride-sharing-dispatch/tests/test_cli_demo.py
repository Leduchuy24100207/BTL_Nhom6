from ride_dispatch import DispatchSystem
from ride_dispatch.cli import ConsoleApp
from ride_dispatch.demo import run_demo


def run_cli(system, lines):
    it = iter(lines)
    out = []
    ConsoleApp(system, input_fn=lambda _="": next(it), print_fn=out.append).run()
    return "\n".join(map(str, out))


def test_demo_runs():
    lines = []
    run_demo(lambda *a: lines.append(" ".join(map(str, a))))
    assert any("consistent" in l or "True" in l for l in lines)


def test_cli_register_login_book_and_logout():
    s = DispatchSystem()
    text = run_cli(s, [
        "1", "kh1", "matkhau1", "1", "Khách Một", "0912345678", "k@x.com",   # đăng ký khách
        "2", "kh1", "matkhau1",                                               # đăng nhập
        "1",                                                                  # menu khách hàng
        "1", "1", "2", "1", "1", "y",   # đặt xe: đón Hồ Gươm, đến Văn Miếu, bike, tiền mặt, xác nhận
        "0", "0", "0",                  # thoát menu
    ])
    assert "Đăng ký thành công" in text and "Xin chào Khách Một" in text
    assert len(s._rides) == 1 and "[Lỗi]" not in text


def test_cli_login_error_shown():
    text = run_cli(DispatchSystem(), ["2", "nobody", "x", "0"])
    assert "[Lỗi]" in text
