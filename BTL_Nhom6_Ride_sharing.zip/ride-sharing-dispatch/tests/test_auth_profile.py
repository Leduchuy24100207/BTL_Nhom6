import pytest

from ride_dispatch import AuthError, PermissionDenied, ValidationError


def test_register_and_login(system):
    system.register("khach1", "abcdef", "customer", "Khách", "0912345678", "k@x.com")
    res = system.login("KHACH1", "abcdef")  # không phân biệt hoa thường
    assert res["user"]["role"] == "customer" and res["token"]


@pytest.mark.parametrize("bad", ["ab", "Has Space", "x" * 31, "", "a@b"])
def test_invalid_username(system, bad):
    with pytest.raises(ValidationError):
        system.register(bad, "abcdef", "customer")


def test_duplicate_and_weak_password(system):
    system.register("khach1", "abcdef", "customer")
    with pytest.raises(ValidationError):
        system.register("khach1", "abcdef", "driver")
    with pytest.raises(ValidationError):
        system.register("khach2", "123", "customer")


def test_invalid_role_phone_email(system):
    with pytest.raises(ValidationError):
        system.register("u1", "abcdef", "boss")
    with pytest.raises(ValidationError):
        system.register("u1", "abcdef", "customer", phone="123")
    with pytest.raises(ValidationError):
        system.register("u1", "abcdef", "customer", email="khong-hop-le")


def test_admin_requires_code(system):
    with pytest.raises(PermissionDenied):
        system.register("adm2", "abcdef", "admin")
    system.register("adm2", "abcdef", "admin", admin_code="ADMIN2026")


def test_wrong_credentials(system):
    system.register("khach1", "abcdef", "customer")
    with pytest.raises(AuthError):
        system.login("khach1", "sai-mat-khau")
    with pytest.raises(AuthError):
        system.login("khong-ton-tai", "abcdef")


def test_logout_invalidates_token(world):
    world.s.logout(world.an)
    with pytest.raises(AuthError):
        world.s.get_profile(world.an)


def test_update_profile(world):
    p = world.s.update_profile(world.an, full_name="An Nguyễn", phone="0900000000", email="n@x.vn")
    assert (p["full_name"], p["phone"], p["email"]) == ("An Nguyễn", "0900000000", "n@x.vn")
    with pytest.raises(ValidationError):
        world.s.update_profile(world.an, phone="abc")
    with pytest.raises(ValidationError):
        world.s.update_profile(world.an, full_name="  ")


def test_customer_cannot_edit_vehicle(world):
    with pytest.raises(PermissionDenied):
        world.s.update_profile(world.an, plate="29A-1")


def test_change_password(world):
    s = world.s
    other = s.login("anh", "secret1")["token"]
    with pytest.raises(AuthError):
        s.change_password(world.an, "sai", "newpass1", "newpass1")
    with pytest.raises(ValidationError):
        s.change_password(world.an, "secret1", "newpass1", "khac-nhau")
    with pytest.raises(ValidationError):
        s.change_password(world.an, "secret1", "secret1", "secret1")
    s.change_password(world.an, "secret1", "newpass1", "newpass1")
    with pytest.raises(AuthError):
        s.login("anh", "secret1")
    assert s.login("anh", "newpass1")["token"]
    s.get_profile(world.an)            # phiên hiện tại còn
    with pytest.raises(AuthError):     # phiên khác bị đăng xuất
        s.get_profile(other)


def test_role_permissions(world):
    s = world.s
    with pytest.raises(PermissionDenied):
        s.list_users(world.an)
    with pytest.raises(PermissionDenied):
        s.top_up(world.an, 1000)       # khách không có ví tài xế
    with pytest.raises(PermissionDenied):
        s.set_price_per_km(world.binh, "car4", 10000)
