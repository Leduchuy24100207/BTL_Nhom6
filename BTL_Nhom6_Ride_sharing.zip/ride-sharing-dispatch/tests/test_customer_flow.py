import pytest

from ride_dispatch import (Location, PermissionDenied, RideStatus, StateError,
                           ValidationError)
from conftest import HOAN_KIEM, MY_DINH, VAN_MIEU, book, new_driver


def test_quote_all_services(world):
    q = world.s.quote_fare(world.an, HOAN_KIEM, MY_DINH)
    assert {x["service"] for x in q} == {"bike", "car4", "car7"}
    by = {x["service"]: x["fare"] for x in q}
    assert by["bike"] < by["car4"] < by["car7"]
    assert all(x["fare"] % 1000 == 0 for x in q)


def test_quote_too_close(world):
    with pytest.raises(ValidationError):
        world.s.quote_fare(world.an, HOAN_KIEM, Location("Gần", HOAN_KIEM.lat, HOAN_KIEM.lng))


def test_book_sends_offer_to_driver(world):
    ride = book(world)
    assert ride["status"] == "searching"
    offers = world.s.list_offers(world.binh)
    assert len(offers) == 1
    o = offers[0]
    assert o["pickup"]["name"] == "Hồ Gươm" and o["dropoff"]["name"] == "Bến xe Mỹ Đình"
    assert o["fare"] == ride["fare"] and o["estimated_net"] == ride["fare"] - round(ride["fare"] * 0.2)


def test_no_driver_when_wrong_service_then_retry(world):
    ride = book(world, service="bike")
    assert ride["status"] == "no_driver"
    new_driver(world, "bike1", HOAN_KIEM, "bike")
    assert world.s.retry_search(world.an, ride["id"])["status"] == "searching"


def test_one_active_ride_per_customer(world):
    book(world)
    with pytest.raises(StateError):
        book(world)


def test_nearest_driver_gets_offer(world):
    far = new_driver(world, "xaxa", MY_DINH)
    ride = book(world)
    assert world.s.list_offers(world.binh) and not world.s.list_offers(far)
    assert ride["status"] == "searching"


def test_reject_goes_to_next_then_no_driver(world):
    other = new_driver(world, "cuong", VAN_MIEU)
    ride = book(world)
    world.s.reject_ride(world.binh, ride["id"])
    assert world.s.list_offers(other)
    res = world.s.reject_ride(other, ride["id"])
    assert res["status"] == "no_driver"


def test_track_and_call_only_while_active(world):
    s = world.s
    ride = book(world)
    with pytest.raises(StateError):
        s.get_driver_contact(world.an, ride["id"])      # chưa nhận
    assert s.track_ride(world.an, ride["id"])["driver_location"] is None
    s.accept_ride(world.binh, ride["id"])
    contact = s.get_driver_contact(world.an, ride["id"])
    assert contact["phone"] == "0987654321" and contact["plate"] == "30A-123.45"
    s.set_location(world.binh, VAN_MIEU)
    tr = s.track_ride(world.an, ride["id"])
    assert tr["status"] == "accepted" and tr["driver_location"]["name"] == "Văn Miếu"
    assert tr["distance_to_target_km"] > 0
    s.start_ride(world.binh, ride["id"])
    assert s.get_driver_contact(world.an, ride["id"])["name"] == "Trần Bình"
    s.complete_ride(world.binh, ride["id"])
    with pytest.raises(StateError):                       # hết chuyến -> không gọi được
        s.get_driver_contact(world.an, ride["id"])
    assert s.track_ride(world.an, ride["id"])["driver_location"] is None


def test_customer_cancel_rules(world):
    s = world.s
    ride = book(world)
    s.accept_ride(world.binh, ride["id"])
    res = s.cancel_ride(world.an, ride["id"], "đổi kế hoạch")
    assert res["status"] == "cancelled"
    assert s.current_ride(world.binh) is None             # tài xế được giải phóng
    r2 = book(world)
    s.accept_ride(world.binh, r2["id"])
    s.start_ride(world.binh, r2["id"])
    with pytest.raises(StateError):
        s.cancel_ride(world.an, r2["id"])                 # đang đi thì không hủy được


def test_cannot_access_other_customer_ride(world):
    s = world.s
    s.register("chi", "secret1", "customer")
    chi = s.login("chi", "secret1")["token"]
    ride = book(world)
    with pytest.raises(PermissionDenied):
        s.track_ride(chi, ride["id"])
    with pytest.raises(PermissionDenied):
        s.cancel_ride(chi, ride["id"])


def test_history_newest_first(world):
    s = world.s
    r1 = book(world)
    s.cancel_ride(world.an, r1["id"])
    world.clock.advance(minutes=5)
    r2 = book(world)
    ids = [r["id"] for r in s.ride_history(world.an)]
    assert ids == [r2["id"], r1["id"]]


def test_rate_driver(world):
    s = world.s
    ride = book(world)
    with pytest.raises(StateError):
        s.rate_driver(world.an, ride["id"], 5)            # chưa hoàn thành
    s.accept_ride(world.binh, ride["id"])
    s.start_ride(world.binh, ride["id"])
    s.complete_ride(world.binh, ride["id"])
    with pytest.raises(ValidationError):
        s.rate_driver(world.an, ride["id"], 6)
    s.rate_driver(world.an, ride["id"], 4, "ổn")
    with pytest.raises(StateError):
        s.rate_driver(world.an, ride["id"], 5)            # chỉ đánh giá 1 lần
    assert s.driver_stats(world.binh)["rating"] == 4.0
