from datetime import datetime, timedelta
from types import SimpleNamespace

import pytest

from ride_dispatch import DispatchSystem, security
from ride_dispatch.places import PLACES

HOAN_KIEM = PLACES["Hồ Gươm"]
VAN_MIEU = PLACES["Văn Miếu"]
MY_DINH = PLACES["Bến xe Mỹ Đình"]
ROYAL = PLACES["Royal City"]


class Clock:
    def __init__(self):
        self.t = datetime(2026, 10, 20, 8, 0, 0)

    def __call__(self):
        return self.t

    def advance(self, **kw):
        self.t += timedelta(**kw)


@pytest.fixture(autouse=True)
def fast_hash(monkeypatch):
    monkeypatch.setattr(security, "ITERATIONS", 1)


@pytest.fixture
def clock():
    return Clock()


@pytest.fixture
def system(clock):
    return DispatchSystem(clock=clock)


@pytest.fixture
def world(system):
    """Admin, khách 'an', tài xế 'binh' (đã duyệt, online gần Hồ Gươm, ví 100k)."""
    s = system
    s.register("admin", "secret1", "admin", "Quản trị", admin_code="ADMIN2026")
    s.register("anh", "secret1", "customer", "Nguyễn An", "0912345678", "anh@mail.com")
    s.register("binh", "secret1", "driver", "Trần Bình", "0987654321", service_type="car4", plate="30A-123.45")
    t = SimpleNamespace(
        s=s, clock=system._clock,
        admin=s.login("admin", "secret1")["token"],
        an=s.login("anh", "secret1")["token"],
        binh=s.login("binh", "secret1")["token"],
    )
    s.approve_driver(t.admin, "binh")
    s.top_up(t.binh, 100_000)
    s.set_online(t.binh, True, HOAN_KIEM)
    return t


def new_driver(w, name, loc, service="car4"):
    w.s.register(name, "secret1", "driver", name.title(), "0900000001", service_type=service)
    tok = w.s.login(name, "secret1")["token"]
    w.s.approve_driver(w.admin, name)
    w.s.set_online(tok, True, loc)
    return tok


def book(w, payment="cash", service="car4", token=None):
    return w.s.book_ride(token or w.an, HOAN_KIEM, MY_DINH, service, payment)
