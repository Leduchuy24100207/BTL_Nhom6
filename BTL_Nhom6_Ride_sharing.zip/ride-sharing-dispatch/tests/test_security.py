import pytest

from ride_dispatch import AuthError, PermissionDenied, ValidationError


def test_invalid_or_forged_session_tokens_are_rejected(world):
    for token in ("", "invalid-token", "admin", " "):
        with pytest.raises(AuthError):
            world.s.get_profile(token)


def test_customer_cannot_access_admin_user_list(world):
    with pytest.raises(PermissionDenied):
        world.s.list_users(world.an)


def test_customer_cannot_change_system_pricing(world):
    with pytest.raises(PermissionDenied):
        world.s.set_price_per_km(world.an, "car4", 1)


def test_admin_registration_requires_correct_secret(system):
    with pytest.raises(PermissionDenied):
        system.register("fakeadmin", "secret1", "admin", admin_code="wrong-code")
    with pytest.raises(PermissionDenied):
        system.register("fakeadmin2", "secret1", "admin")


def test_password_is_not_stored_as_plain_text(system):
    system.register("secureuser", "my-secret-password", "customer")
    user = system._users["secureuser"]
    assert user.password_hash != "my-secret-password"
    assert user.salt
    assert len(user.password_hash) == 64


def test_password_change_invalidates_other_sessions(world):
    second_session = world.s.login("anh", "secret1")["token"]
    world.s.change_password(world.an, "secret1", "new-secret-1", "new-secret-1")
    with pytest.raises(AuthError):
        world.s.get_profile(second_session)
    assert world.s.get_profile(world.an)["username"] == "anh"


def test_locked_account_cannot_keep_using_existing_session(world):
    world.s.lock_user(world.admin, "anh", "security test")
    with pytest.raises(AuthError):
        world.s.get_profile(world.an)


def test_invalid_contact_data_is_rejected(system):
    with pytest.raises(ValidationError):
        system.register("badphone", "secret1", "customer", phone="123")
    with pytest.raises(ValidationError):
        system.register("bademail", "secret1", "customer", email="not-an-email")


def test_logout_revokes_session(world):
    world.s.logout(world.an)
    with pytest.raises(AuthError):
        world.s.get_profile(world.an)
